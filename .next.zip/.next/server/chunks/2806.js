"use strict";
exports.id = 2806;
exports.ids = [2806];
exports.modules = {

/***/ 2806:
/***/ ((module) => {

module.exports = JSON.parse('{"Xd":{"aD":"Mywater - Drink Smart","Tb":"https://formspree.io/f/meojgend"},"Fs":{"jY":{"BH":"/images/logo-black.png","gB":"/images/logo-main.png","wp":"logo"},"GI":[{"label":"About Us","link":"/about","children":0},{"label":"Products","link":"/products","children":[{"label":"Shop All","link":"/products","children":0},{"label":"For Homes","link":"/products","children":0},{"label":"For Corporate","link":"/products","children":0},{"label":"For Offices","link":"/products","children":0},{"label":"Limited Edition","link":"/products","children":0}]},{"label":"Our Team","link":"/team","children":0},{"label":"Offers","link":"/promo","children":0},{"label":"Careers","link":"https://app.myhcm.pk/CareerPortal/Careers?q=olBwJs6tOQ9sgxyMavM%2BVQ%3D%3D&lang=null","children":0},{"label":"Contact Us","link":"/contact","children":0},{"label":"FAQs","link":"/faq","children":0}],"LI":{"P":"Monthly Rental","p":"/products"}},"Mv":{"jY":{"B":"/images/logo-black.png","w":"logo"},"JG":"© 2024-25 Copyright MYWATER&trade;<a href=\'\' target=\'blank\' class=\'onovo-lnk lnk--white\'></a>. Pvt Limited."},"xs":[{"link":"https://www.facebook.com/mywaterpk","icon":"fab fa-facebook","title":"Facebook"},{"link":"https://www.instagram.com/mywaterpk","icon":"fab fa-instagram","title":"Instagram"},{"link":"https://www.linkedin.com/company/mywaterpk/","icon":"fab fa-linkedin","title":"Linkedin"},{"link":"https://wa.me/021111192837","icon":"fab fa-whatsapp","title":"Linkedin"}]}');

/***/ })

};
;